# hello.pyx - Cython source file
# Notice: looks almost identical to Python
# but with optional C type declarations

# ─────────────────────────────────────────
# 1. Basic function - no type hints (pure Python speed)
# ─────────────────────────────────────────
def say_hello(name):
    return f"Hello {name} from Cython!"


# ─────────────────────────────────────────
# 2. Typed function - C types = much faster
# ─────────────────────────────────────────
def add_numbers(int a, int b):
    cdef int result        # C integer - faster than Python int
    result = a + b
    return result


# ─────────────────────────────────────────
# 3. Loop - where Cython really shines
#    Compare this vs pure Python loop speed
# ─────────────────────────────────────────
def sum_numbers(int n):
    cdef int i             # C integer loop counter
    cdef long total = 0    # C long for large sums
    for i in range(n):
        total += i
    return total


# ─────────────────────────────────────────
# 4. C-level function (cdef) - fastest
#    Only callable from Cython, not Python
# ─────────────────────────────────────────
cdef double multiply(double a, double b):
    return a * b


# ─────────────────────────────────────────
# 5. cpdef - callable from both Python AND Cython
# ─────────────────────────────────────────
cpdef double circle_area(double radius):
    cdef double pi = 3.14159265358979
    return pi * radius * radius
