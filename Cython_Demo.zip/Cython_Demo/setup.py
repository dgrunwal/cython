# setup.py - tells Python how to compile the Cython file
from setuptools import setup
from Cython.Build import cythonize

setup(
    name="hello-cython",
    ext_modules=cythonize(
        "hello.pyx",
        compiler_directives={
            "language_level": "3"    # Use Python 3 syntax
        }
    )
)
