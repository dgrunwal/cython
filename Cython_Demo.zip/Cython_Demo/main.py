# main.py - import and test the compiled Cython module
import time
import hello    # imports our compiled hello.pyx


# ─────────────────────────────────────────
# Test each function
# ─────────────────────────────────────────
print("=" * 40)
print("CYTHON FUNCTION TESTS")
print("=" * 40)

# 1. Basic hello
print(hello.say_hello("Karen"))

# 2. Add numbers
result = hello.add_numbers(42, 58)
print(f"42 + 58 = {result}")

# 3. Circle area
area = hello.circle_area(5.0)
print(f"Circle area (radius=5): {area:.4f}")

# 4. Sum numbers
total = hello.sum_numbers(1000)
print(f"Sum 0 to 999 = {total}")


# ─────────────────────────────────────────
# Benchmark: Cython vs Pure Python
# ─────────────────────────────────────────
print("\n" + "=" * 40)
print("BENCHMARK: Cython vs Python")
print("=" * 40)

N = 10_000_000  # 10 million iterations

# Pure Python version
def python_sum(n):
    total = 0
    for i in range(n):
        total += i
    return total

# Time pure Python
start = time.time()
python_result = python_sum(N)
python_time = time.time() - start

# Time Cython
start = time.time()
cython_result = hello.sum_numbers(N)
cython_time = time.time() - start

print(f"Pure Python : {python_time:.4f} seconds")
print(f"Cython      : {cython_time:.4f} seconds")
print(f"Speedup     : {python_time / cython_time:.1f}x faster")
print(f"Results match: {python_result == cython_result}")
